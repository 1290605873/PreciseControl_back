<template>
    <div>检查项目设置</div>
</template>
